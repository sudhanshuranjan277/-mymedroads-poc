DELETE FROM doctors;


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
1,
1,
'Artemis Hospitals',
'Dr. (Col) Balbir Kalra',
'Associate Chief - Cardiology (NIC)',
'Associate Chief - Cardiology (NIC)',
'https://www.artemishospitals.com/doctor/profile/balbir-kalra'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
2,
1,
'Artemis Hospitals',
'Dr. (Col) S. V. Kotwal',
'Chairperson Emeritus and DNB Teacher - Urology',
'Chairperson Emeritus and DNB Teacher - Urology',
'https://www.artemishospitals.com/doctor/profile/s-v-kotwal'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
3,
1,
'Artemis Hospitals',
'Dr. (Col) Suvasish Chakraberty',
'Chief - Emergency',
'Chief - Emergency',
'https://www.artemishospitals.com/doctor/profile/col-suvasish-chakraberty'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
4,
1,
'Artemis Hospitals',
'Dr. (Prof.) Ravi Sauhta',
'Chief and HOD - Orthopaedics & Joint Replacement (Unit VI)',
'Chief and HOD - Orthopaedics & Joint Replacement (Unit VI)',
'https://www.artemishospitals.com/doctor/profile/prof-ravi-sauhta'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
5,
1,
'Artemis Hospitals',
'Dr. A.B. Dey',
'Chairperson - Geriatric Medicine',
'Chairperson - Geriatric Medicine',
'https://www.artemishospitals.com/doctor/profile/dr-a-b-dey'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
6,
1,
'Artemis Hospitals',
'Dr. Aanchal Sablok',
'Senior Consultant - Fetal Medicine',
'Senior Consultant - Fetal Medicine',
'https://www.artemishospitals.com/doctor/profile/dr-aanchal-sablok'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
7,
1,
'Artemis Hospitals',
'Dr. Abhinandan Mukhopadhyay',
'Sr. Consultant - Urology & Kidney Transplant Program (Unit I)',
'Sr. Consultant - Urology & Kidney Transplant Program (Unit I)',
'https://www.artemishospitals.com/doctor/profile/dr-abhinandan-mukhopadhyay'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
8,
1,
'Artemis Hospitals',
'Dr. Aditi Dixit',
'Sr. Consultant – Women Imaging',
'Sr. Consultant – Women Imaging',
'https://www.artemishospitals.com/doctor/profile/aditi-dixit'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
9,
1,
'Artemis Hospitals',
'Dr. Aditya Gupta',
'Chairperson - Neurosurgery & CNS Radiosurgery & Co-Chief - Cyberknife Centre',
'Chairperson - Neurosurgery & CNS Radiosurgery & Co-Chief - Cyberknife Centre',
'https://www.artemishospitals.com/doctor/profile/aditya-gupta'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
10,
1,
'Artemis Hospitals',
'Dr. Ajit Singh Baghela',
'Sr. Consultant - Paediatric Neurology',
'Sr. Consultant - Paediatric Neurology',
'https://www.artemishospitals.com/doctor/profile/ajit-singh-baghela'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
11,
1,
'Artemis Hospitals',
'Dr. Amit Jassal',
'Principal Consultant - Anaesthesia',
'Principal Consultant - Anaesthesia',
'https://www.artemishospitals.com/doctor/profile/amit-jassal'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
12,
1,
'Artemis Hospitals',
'Dr. Amit Kalsotra',
'Sr. Consultant - Anaesthesia',
'Sr. Consultant - Anaesthesia',
'https://www.artemishospitals.com/doctor/profile/amit-kalsotra'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
13,
1,
'Artemis Hospitals',
'Dr. Amit Kumar Chaurasia',
'Chief Cath Lab & TAVI (Unit I)',
'Chief Cath Lab & TAVI (Unit I)',
'https://www.artemishospitals.com/doctor/profile/amit-kumar-chaurasia'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
14,
1,
'Artemis Hospitals',
'Dr. Amit Sharma',
'Consultant (Preventive Health Checks & Internal Medicine)',
'Consultant (Preventive Health Checks & Internal Medicine)',
'https://www.artemishospitals.com/doctor/profile/dr-amit-sharma'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
15,
1,
'Artemis Hospitals',
'Dr. Anjali Vaish',
'Consultant - Physiotherapy and Rehabilitation Centre',
'Consultant - Physiotherapy and Rehabilitation Centre',
'https://www.artemishospitals.com/doctor/profile/dr-anjali-vaish'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
16,
1,
'Artemis Hospitals',
'Dr. Anjana Kharbanda',
'Sr. Consultant - Emergency',
'Sr. Consultant - Emergency',
'https://www.artemishospitals.com/doctor/profile/anjana-kharbanda'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
17,
1,
'Artemis Hospitals',
'Dr. Anjana Satyajit',
'Head - Dentistry',
'Head - Dentistry',
'https://www.artemishospitals.com/doctor/profile/anjana-satyajit'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
18,
1,
'Artemis Hospitals',
'Dr. Anju Singh',
'Consultant - Pediatric Rheumatology',
'Consultant - Pediatric Rheumatology',
'https://www.artemishospitals.com/doctor/profile/dr-anju-singh'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
19,
1,
'Artemis Hospitals',
'Dr. Ankit Goel',
'Consultant - Urology & Renal Transplant',
'Consultant - Urology & Renal Transplant',
'https://www.artemishospitals.com/doctor/profile/dr-ankit-goyal'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
20,
1,
'Artemis Hospitals',
'Dr. Ankur Bhatia',
'Consultant Plastic Surgeon',
'Consultant Plastic Surgeon',
'https://www.artemishospitals.com/doctor/profile/dr-ankur-bhatia'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
21,
1,
'Artemis Hospitals',
'Dr. Anuradha Khurana',
'Sr. Consultant',
'Sr. Consultant',
'https://www.artemishospitals.com/doctor/profile/dr-anuradha-khurana'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
22,
1,
'Artemis Hospitals',
'Dr. Anuvrat Sinha',
'Consultant Neurosurgery',
'Consultant Neurosurgery',
'https://www.artemishospitals.com/doctor/profile/dr-anuvrat-sinha'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
23,
1,
'Artemis Hospitals',
'Dr. Arpit Jain',
'Head – Internal Medicine',
'Head – Internal Medicine',
'https://www.artemishospitals.com/doctor/profile/arpit-jain'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
24,
1,
'Artemis Hospitals',
'Dr. Arun Chowdary Kotaru',
'Unit Head & Sr. Consultant - Respiratory Disease & Sleep Medicine (Unit I) - Heart & Lung Transplant',
'Unit Head & Sr. Consultant - Respiratory Disease & Sleep Medicine (Unit I) - Heart & Lung Transplant',
'https://www.artemishospitals.com/doctor/profile/arun-chowdary-kotaru'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
25,
1,
'Artemis Hospitals',
'Dr. Arun Singh Danewa',
'Senior Consultant – Pediatric-Haemato-Oncology & Bone Marrow Transplant (Unit II)',
'Senior Consultant – Pediatric-Haemato-Oncology & Bone Marrow Transplant (Unit II)',
'https://www.artemishospitals.com/doctor/profile/dr-arun-singh-danewa'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
26,
1,
'Artemis Hospitals',
'Dr. Aseem R. Srivastava',
'Chief- Pediatric CTVS and Adult Congenital Heart Diseases',
'Chief- Pediatric CTVS and Adult Congenital Heart Diseases',
'https://www.artemishospitals.com/doctor/profile/aseem-r-srivastava'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
27,
1,
'Artemis Hospitals',
'Dr. Ashish Chakravarty',
'Head - Neurosciences Pain Medicine & Principal Consultant - Neuro Anaesthesia',
'Head - Neurosciences Pain Medicine & Principal Consultant - Neuro Anaesthesia',
'https://www.artemishospitals.com/doctor/profile/ashish-chakravarty'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
28,
1,
'Artemis Hospitals',
'Dr. Ashu Kumar Jain',
'Chief – Pain Medicine & Palliative Care',
'Chief – Pain Medicine & Palliative Care',
'https://www.artemishospitals.com/doctor/profile/ashu-kumar-jain'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
29,
1,
'Artemis Hospitals',
'Dr. Ashutosh Gupta',
'Head – Medical Genetics',
'Head – Medical Genetics',
'https://www.artemishospitals.com/doctor/profile/ashutosh-gupta'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
30,
1,
'Artemis Hospitals',
'Dr. Atul Sharma',
'Chief – Motility and Third Space',
'Chief – Motility and Third Space',
'https://www.artemishospitals.com/doctor/profile/dr-atul-sharma'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
31,
1,
'Artemis Hospitals',
'Dr. Bimal Kumar Sahu',
'Sr. Consultant Unit In charge',
'Sr. Consultant Unit In charge',
'https://www.artemishospitals.com/doctor/profile/dr-bimal-kumar-sahu'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
32,
1,
'Artemis Hospitals',
'Dr. Biswarup Purkayastha',
'Consultant – Heart & Lung Transplant and Vascular Surgery',
'Consultant – Heart & Lung Transplant and Vascular Surgery',
'https://www.artemishospitals.com/doctor/profile/dr-biswarup-purkayastha'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
33,
1,
'Artemis Hospitals',
'Dr. Chandrima Misra Mukherjee',
'Co-Head Psychological Services',
'Co-Head Psychological Services',
'https://www.artemishospitals.com/doctor/profile/dr-chandrima-misra-mukerjee'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
34,
1,
'Artemis Hospitals',
'Dr. D.K. Jhamb',
'Chief Cardiology (Unit IV)',
'Chief Cardiology (Unit IV)',
'https://www.artemishospitals.com/doctor/profile/dr-d-k-jhamb'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
35,
1,
'Artemis Hospitals',
'Dr. Deeksha Kalra',
'Associate Consultant – Psychiatry',
'Associate Consultant – Psychiatry',
'https://www.artemishospitals.com/doctor/profile/dr-deeksha-kalra'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
36,
1,
'Artemis Hospitals',
'Dr. Deepa Goel',
'Head - Histopathology & Cytology Lab',
'Head - Histopathology & Cytology Lab',
'https://www.artemishospitals.com/doctor/profile/deepa-goel'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
37,
1,
'Artemis Hospitals',
'Dr. Deepak Jha',
'Chief - Breast Surgery & Sr. Consultant : Surgical Oncology',
'Chief - Breast Surgery & Sr. Consultant : Surgical Oncology',
'https://www.artemishospitals.com/doctor/profile/deepak-jha'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
38,
1,
'Artemis Hospitals',
'Dr. Deepak Solanki',
'Sr. Consultant - Neuro Anaesthesia & Neuro Critical Care',
'Sr. Consultant - Neuro Anaesthesia & Neuro Critical Care',
'https://www.artemishospitals.com/doctor/profile/deepak-solanki'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
39,
1,
'Artemis Hospitals',
'Dr. Deepika Aggarwal',
'Chief-Laparoscopic Gynae & Robotic Surgery',
'Chief-Laparoscopic Gynae & Robotic Surgery',
'https://www.artemishospitals.com/doctor/profile/dr-deepika-aggarwal'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
40,
1,
'Artemis Hospitals',
'Dr. Devendra Singh Solanki',
'Head Unit I',
'Head Unit I',
'https://www.artemishospitals.com/doctor/profile/devendra-singh-solanki'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
41,
1,
'Artemis Hospitals',
'Dr. Devendra Yadav',
'Unit Head - Orthopaedics (Unit VI)',
'Unit Head - Orthopaedics (Unit VI)',
'https://www.artemishospitals.com/doctor/profile/devendra-yadav'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
42,
1,
'Artemis Hospitals',
'Dr. Dheeraj Batheja',
'Senior Consultant -Ortho Spine Surgery',
'Senior Consultant -Ortho Spine Surgery',
'https://www.artemishospitals.com/doctor/profile/dr-dheeraj-batheja'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
43,
1,
'Artemis Hospitals',
'Dr. Dheeraj Kapoor',
'Chief - Endocrinology',
'Chief - Endocrinology',
'https://www.artemishospitals.com/doctor/profile/dheeraj-kapoor'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
44,
1,
'Artemis Hospitals',
'Dr. Dilpreet Bajwa',
'Sr. Consultant',
'Sr. Consultant',
'https://www.artemishospitals.com/doctor/profile/dilpreet-bajwa'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
45,
1,
'Artemis Hospitals',
'Dr. Dinesh Bansal',
'Chief Nephrology (Unit III)',
'Chief Nephrology (Unit III)',
'https://www.artemishospitals.com/doctor/profile/dr-dinesh-bansal'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
46,
1,
'Artemis Hospitals',
'Dr. Ellora Nanda',
'Admin Head - Emergency',
'Admin Head - Emergency',
'https://www.artemishospitals.com/doctor/profile/ellora-nanda'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
47,
1,
'Artemis Hospitals',
'Dr. G. Arya Prakash',
'Head - Anesthesia for Liver transplant',
'Head - Anesthesia for Liver transplant',
'https://www.artemishospitals.com/doctor/profile/g-arya-prakash'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
48,
1,
'Artemis Hospitals',
'Dr. Gaurav Dixit',
'Head – Haematology Oncology & Bone Marrow Transplant (Unit II)',
'Head – Haematology Oncology & Bone Marrow Transplant (Unit II)',
'https://www.artemishospitals.com/doctor/profile/dr-gaurav-dixit'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
49,
1,
'Artemis Hospitals',
'Dr. Gaurav Singhal',
'Consultant – of Nephrology',
'Consultant – of Nephrology',
'https://www.artemishospitals.com/doctor/profile/dr-gaurav-singhal'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
50,
1,
'Artemis Hospitals',
'Dr. Giriraj Bora',
'Chairperson - Liver Transplant & Sr. Consultant - GI & HPB Surgery',
'Chairperson - Liver Transplant & Sr. Consultant - GI & HPB Surgery',
'https://www.artemishospitals.com/doctor/profile/giriraj-bora'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
51,
1,
'Artemis Hospitals',
'Dr. Gurpreet Makkar',
'Head Imaging & Chief DNB Program',
'Head Imaging & Chief DNB Program',
'https://www.artemishospitals.com/doctor/profile/gurpreet-makkar'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
52,
1,
'Artemis Hospitals',
'Dr. Hari Goyal',
'Chief - Medical Oncology',
'Chief - Medical Oncology',
'https://www.artemishospitals.com/doctor/profile/dr-hari-goyal'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
53,
1,
'Artemis Hospitals',
'Dr. Hemant K. Gogia',
'Sr. Consultant - Paediatrics',
'Sr. Consultant - Paediatrics',
'https://www.artemishospitals.com/doctor/profile/hemant-k-gogia'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
54,
1,
'Artemis Hospitals',
'Dr. Hitender Singh Chauhan',
'Associate Consultant',
'Associate Consultant',
'https://www.artemishospitals.com/doctor/profile/dr-hitender-singh-chauhan'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
55,
1,
'Artemis Hospitals',
'Dr. Hitesh Garg',
'Head - Ortho Spine Surgery',
'Head - Ortho Spine Surgery',
'https://www.artemishospitals.com/doctor/profile/hitesh-garg'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
56,
1,
'Artemis Hospitals',
'Dr. I P S Oberoi',
'Chairperson - Orthopaedics Program & Chief – Robotic Joint Replacement & Arthroscopy Surgery',
'Chairperson - Orthopaedics Program & Chief – Robotic Joint Replacement & Arthroscopy Surgery',
'https://www.artemishospitals.com/doctor/profile/i-p-s-oberoi'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
57,
1,
'Artemis Hospitals',
'Dr. Jeetendra Sharma',
'Chief - Critical Care (Unit II) & Chief- Medical Quality',
'Chief - Critical Care (Unit II) & Chief- Medical Quality',
'https://www.artemishospitals.com/doctor/profile/jeetendra-sharma'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
58,
1,
'Artemis Hospitals',
'Dr. Kamal Verma',
'Principal Consultant - Radiation Oncology',
'Principal Consultant - Radiation Oncology',
'https://www.artemishospitals.com/doctor/profile/kamal-verma'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
59,
1,
'Artemis Hospitals',
'Dr. Kanika Singh',
'Sr. Consultant - Medical Genetics',
'Sr. Consultant - Medical Genetics',
'https://www.artemishospitals.com/doctor/profile/dr-kanika-singh'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
60,
1,
'Artemis Hospitals',
'Dr. Kapil Dev Jamwal',
'Chief – Innovation & GI Interventions and Head – Gastroenterology & Hepatology',
'Chief – Innovation & GI Interventions and Head – Gastroenterology & Hepatology',
'https://www.artemishospitals.com/doctor/profile/dr-kapil-dev-jamwal'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
61,
1,
'Artemis Hospitals',
'Dr. Kiran Arora',
'Unit Head - Reproductive Medicine (Unit II)',
'Unit Head - Reproductive Medicine (Unit II)',
'https://www.artemishospitals.com/doctor/profile/kiran-arora'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
62,
1,
'Artemis Hospitals',
'Dr. Kuldeep Arora',
'Unit Head & Chief Cath Lab (Unit II)',
'Unit Head & Chief Cath Lab (Unit II)',
'https://www.artemishospitals.com/doctor/profile/kuldeep-arora'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
63,
1,
'Artemis Hospitals',
'Dr. Kuldeep Singh',
'Chief - Critical Care',
'Chief - Critical Care',
'https://www.artemishospitals.com/doctor/profile/kuldeep-singh'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
64,
1,
'Artemis Hospitals',
'Dr. Kunal Vinayak',
'Associate Consultant - Urology & Kidney Transplant',
'Associate Consultant - Urology & Kidney Transplant',
'https://www.artemishospitals.com/doctor/profile/dr-kunal-vinayak'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
65,
1,
'Artemis Hospitals',
'Dr. Lalit Kumar',
'Chairperson - Oncology & BMT',
'Chairperson - Oncology & BMT',
'https://www.artemishospitals.com/doctor/profile/dr-lalit-kumar'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
66,
1,
'Artemis Hospitals',
'Dr. M.A Mir',
'Head - Gastroenterology - Liver & Digestive Diseases (Unit III)',
'Head - Gastroenterology - Liver & Digestive Diseases (Unit III)',
'https://www.artemishospitals.com/doctor/profile/m-a-mir'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
67,
1,
'Artemis Hospitals',
'Dr. Manju Aggarwal',
'Chief - Medical Services & Chairperson - Nephrology',
'Chief - Medical Services & Chairperson - Nephrology',
'https://www.artemishospitals.com/doctor/profile/manju-aggarwal'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
68,
1,
'Artemis Hospitals',
'Dr. Manjul Bawa',
'Consultant – Robotic, Bariatric, Laparoscopic , Laser & General Surgery',
'Consultant – Robotic, Bariatric, Laparoscopic , Laser & General Surgery',
'https://www.artemishospitals.com/doctor/profile/dr-manjul-bawa'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
69,
1,
'Artemis Hospitals',
'Dr. Mansi Dhende',
'Consultant Plastic Surgeon',
'Consultant Plastic Surgeon',
'https://www.artemishospitals.com/doctor/profile/dr-mansi-dhende'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
70,
1,
'Artemis Hospitals',
'Dr. Mayank Madan',
'Chief - Robotic, Bariatric, Minimal Access & General Surgery',
'Chief - Robotic, Bariatric, Minimal Access & General Surgery',
'https://www.artemishospitals.com/doctor/profile/dr-mayank-madan'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
71,
1,
'Artemis Hospitals',
'Dr. Meenal Thakral',
'Associate Consultant',
'Associate Consultant',
'https://www.artemishospitals.com/doctor/profile/dr-meenal-thakral'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
72,
1,
'Artemis Hospitals',
'Dr. Mohit Anand',
'Consultant - Neurology & Movement Disorders',
'Consultant - Neurology & Movement Disorders',
'https://www.artemishospitals.com/doctor/profile/dr-mohit-anand'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
73,
1,
'Artemis Hospitals',
'Dr. Monica Bambroo',
'Head - Dermatology',
'Head - Dermatology',
'https://www.artemishospitals.com/doctor/profile/monica-bambroo'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
74,
1,
'Artemis Hospitals',
'Dr. Mukesh Kumar',
'Consultant - Neuro Interventional Surgery',
'Consultant - Neuro Interventional Surgery',
'https://www.artemishospitals.com/doctor/profile/dr-mukesh-kumar'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
75,
1,
'Artemis Hospitals',
'Dr. Mukesh Kumar Gupta',
'Head - Critical Care (Unit III) & Heart & Lung Transplant',
'Head - Critical Care (Unit III) & Heart & Lung Transplant',
'https://www.artemishospitals.com/doctor/profile/mukesh-kumar-gupta'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
76,
1,
'Artemis Hospitals',
'Dr. Namita Jaggi',
'Chairperson- Lab services and Infection control & Chief- Education & Research',
'Chairperson- Lab services and Infection control & Chief- Education & Research',
'https://www.artemishospitals.com/doctor/profile/namita-jaggi'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
77,
1,
'Artemis Hospitals',
'Dr. Nandini Vasdev',
'Head Lab medicine – Head Histopathology & Cytology',
'Head Lab medicine – Head Histopathology & Cytology',
'https://www.artemishospitals.com/doctor/profile/nandini-vasdev'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
78,
1,
'Artemis Hospitals',
'Dr. Narender Kumar',
'Head - Urology and Kidney Transplant Anesthesia',
'Head - Urology and Kidney Transplant Anesthesia',
'https://www.artemishospitals.com/doctor/profile/narender-kumar'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
79,
1,
'Artemis Hospitals',
'Dr. Nidhi Jain',
'Sr. Consultant - Obs & Gynae',
'Sr. Consultant - Obs & Gynae',
'https://www.artemishospitals.com/doctor/profile/nidhi-jain'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
80,
1,
'Artemis Hospitals',
'Dr. Nidhi Rajotia (Goel)',
'Unit Head - Obs & Gynae',
'Unit Head - Obs & Gynae',
'https://www.artemishospitals.com/doctor/profile/nidhi-rajotia-goel'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
81,
1,
'Artemis Hospitals',
'Dr. Nidhi Rawal',
'Chief - Paediatric Cardiology',
'Chief - Paediatric Cardiology',
'https://www.artemishospitals.com/doctor/profile/nidhi-rawal'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
82,
1,
'Artemis Hospitals',
'Dr. Nitin Goel',
'Sr. Consultant',
'Sr. Consultant',
'https://www.artemishospitals.com/doctor/profile/nitin-goel'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
83,
1,
'Artemis Hospitals',
'Dr. Noaline Sinha',
'Chairperson - Nuclear Medicine & Radio-Theranostics',
'Chairperson - Nuclear Medicine & Radio-Theranostics',
'https://www.artemishospitals.com/doctor/profile/noaline-sinha'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
84,
1,
'Artemis Hospitals',
'Dr. Padam Yadav',
'Consultant',
'Consultant',
'https://www.artemishospitals.com/doctor/profile/padam-yadav'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
85,
1,
'Artemis Hospitals',
'Dr. Paritosh S Gupta',
'Chairperson – General, Minimal Access, Bariatric & Robotic Surgery',
'Chairperson – General, Minimal Access, Bariatric & Robotic Surgery',
'https://www.artemishospitals.com/doctor/profile/paritosh-s-gupta'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
86,
1,
'Artemis Hospitals',
'Dr. Parul Prakash',
'Head - Reproductive Medicine (IVF)',
'Head - Reproductive Medicine (IVF)',
'https://www.artemishospitals.com/doctor/profile/dr-parul-prakash'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
87,
1,
'Artemis Hospitals',
'Dr. Parveen Yadav',
'Chief & Senior Consultant – Minimal Invasive & Robotic Thoracic Onco Surgery',
'Chief & Senior Consultant – Minimal Invasive & Robotic Thoracic Onco Surgery',
'https://www.artemishospitals.com/doctor/profile/parveen-yadav'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
88,
1,
'Artemis Hospitals',
'Dr. Pawan Goyal',
'Associate Chief - Neurosurgery & Head - Neuroendoscopy',
'Associate Chief - Neurosurgery & Head - Neuroendoscopy',
'https://www.artemishospitals.com/doctor/profile/pawan-goyal'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
89,
1,
'Artemis Hospitals',
'Dr. Piush Girdhar',
'Sr. Consultant',
'Sr. Consultant',
'https://www.artemishospitals.com/doctor/profile/dr-piush-girdhar'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
90,
1,
'Artemis Hospitals',
'Dr. Piyush Gupta',
'Senior Consultant Urology and Andrology/ Renal Transplant Surgeon/ Robotic Surgery Specialist',
'Senior Consultant Urology and Andrology/ Renal Transplant Surgeon/ Robotic Surgery Specialist',
'https://www.artemishospitals.com/doctor/profile/dr-piyush-gupta'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
91,
1,
'Artemis Hospitals',
'Dr. Poonam Gautam',
'Sr. Consultant',
'Sr. Consultant',
'https://www.artemishospitals.com/doctor/profile/dr-poonam-gautam'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
92,
1,
'Artemis Hospitals',
'Dr. Prabhat Maheshwari',
'Chief- Neonatal & Paediatric Critical Care',
'Chief- Neonatal & Paediatric Critical Care',
'https://www.artemishospitals.com/doctor/profile/prabhat-maheshwari'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
93,
1,
'Artemis Hospitals',
'Dr. Pradeep Kumar Singh',
'Head - Cosmetic & Plastic Surgery',
'Head - Cosmetic & Plastic Surgery',
'https://www.artemishospitals.com/doctor/profile/dr-pradeep-kumar-singh'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
94,
1,
'Artemis Hospitals',
'Dr. Preeti Vijayakumaran',
'Consultant',
'Consultant',
'https://www.artemishospitals.com/doctor/profile/dr-preeti-vijayakumaran'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
95,
1,
'Artemis Hospitals',
'Dr. Priya Tiwari',
'Head - Medical Oncology',
'Head - Medical Oncology',
'https://www.artemishospitals.com/doctor/profile/priya-tiwari'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
96,
1,
'Artemis Hospitals',
'Dr. Priyanka Raina',
'Senior Consultant (Head & Neck Surgery) - Surgical Oncology',
'Senior Consultant (Head & Neck Surgery) - Surgical Oncology',
'https://www.artemishospitals.com/doctor/profile/dr-priyanka-raina'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
97,
1,
'Artemis Hospitals',
'Dr. Puneet Dwevedi',
'Chief',
'Chief',
'https://www.artemishospitals.com/doctor/profile/dr-puneet-dwevedi'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
98,
1,
'Artemis Hospitals',
'Dr. Radhika Narsingdas Sarda',
'Associate Consultant',
'Associate Consultant',
'https://www.artemishospitals.com/doctor/profile/dr-radhika-narsingdas-sarda'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
99,
1,
'Artemis Hospitals',
'Dr. Rahul Chandhok',
'Head',
'Head',
'https://www.artemishospitals.com/doctor/profile/dr-rahul-chandhok'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
100,
1,
'Artemis Hospitals',
'Dr. Rahul Mehrotra',
'Chief - NIC & Clinical Cardiology',
'Chief - NIC & Clinical Cardiology',
'https://www.artemishospitals.com/doctor/profile/dr-rahul-mehrotra'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
101,
1,
'Artemis Hospitals',
'Dr. Rahul Naithani',
'Chief - Hematology, Oncology & Bone Marrow Transplant',
'Chief - Hematology, Oncology & Bone Marrow Transplant',
'https://www.artemishospitals.com/doctor/profile/dr-rahul-naithani'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
102,
1,
'Artemis Hospitals',
'Dr. Rajesh Kumar Padhan',
'Chief – Academic and Training, Gastroenterology and Hepatology',
'Chief – Academic and Training, Gastroenterology and Hepatology',
'https://www.artemishospitals.com/doctor/profile/dr-rajesh-kumar-padhan'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
103,
1,
'Artemis Hospitals',
'Dr. Rajesh Kumar Singh',
'Head - Clinical, Emergency & Trauma Services & Coordinator Medical Education & Corporate Training.',
'Head - Clinical, Emergency & Trauma Services & Coordinator Medical Education & Corporate Training.',
'https://www.artemishospitals.com/doctor/profile/rajesh-kumar-singh'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
104,
1,
'Artemis Hospitals',
'Dr. Rajesh Misra',
'Chairperson - Anaesthesia',
'Chairperson - Anaesthesia',
'https://www.artemishospitals.com/doctor/profile/rajesh-mishra'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
105,
1,
'Artemis Hospitals',
'Dr. Rajiv Chhabra',
'Chief',
'Chief',
'https://www.artemishospitals.com/doctor/profile/dr-rajiv-chhabra'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
106,
1,
'Artemis Hospitals',
'Dr. Rajiv Sharma',
'Head – Interventional Radiology',
'Head – Interventional Radiology',
'https://www.artemishospitals.com/doctor/profile/rajiv-sharma'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
107,
1,
'Artemis Hospitals',
'Dr. Rajiv Yadav',
'Chairperson Urology & Head, Urologic Oncology & Robotic Surgery (Unit I)',
'Chairperson Urology & Head, Urologic Oncology & Robotic Surgery (Unit I)',
'https://www.artemishospitals.com/doctor/profile/dr-rajiv-yadav'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
108,
1,
'Artemis Hospitals',
'Dr. Rakesh Durkhure',
'Head - General, MI & Bariatric Surgery (Unit IV)',
'Head - General, MI & Bariatric Surgery (Unit IV)',
'https://www.artemishospitals.com/doctor/profile/dr-rakesh-durkhure'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
109,
1,
'Artemis Hospitals',
'Dr. Raman Deep Kaur',
'Sr. Consultant - Neuro Anaesthesia & Neuro Critical Care',
'Sr. Consultant - Neuro Anaesthesia & Neuro Critical Care',
'https://www.artemishospitals.com/doctor/profile/dr-raman-deep-kaur'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
110,
1,
'Artemis Hospitals',
'Dr. Ranchit Narang',
'Classified Specialist',
'Classified Specialist',
'https://www.artemishospitals.com/doctor/profile/dr-ranchit-narang'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
111,
1,
'Artemis Hospitals',
'Dr. Rati Bansal Goel',
'Head - Critical Care (Unit III)',
'Head - Critical Care (Unit III)',
'https://www.artemishospitals.com/doctor/profile/rati-bansal-goel'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
112,
1,
'Artemis Hospitals',
'Dr. Renu Raina Sehgal',
'Chairperson - of Obstetrics & Gynaecology',
'Chairperson - of Obstetrics & Gynaecology',
'https://www.artemishospitals.com/doctor/profile/renu-raina-sehgal'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
113,
1,
'Artemis Hospitals',
'Dr. Reshma Tewari',
'Chief Critical Care (Unit I)',
'Chief Critical Care (Unit I)',
'https://www.artemishospitals.com/doctor/profile/reshma-tewari'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
114,
1,
'Artemis Hospitals',
'Dr. Ritika Singla',
'Sr. Consultant - Lab Medicine',
'Sr. Consultant - Lab Medicine',
'https://www.artemishospitals.com/doctor/profile/ritika-singla'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
115,
1,
'Artemis Hospitals',
'Dr. S Jayalakshmi',
'Chief - Radiation Oncology & CyberKnife Centre',
'Chief - Radiation Oncology & CyberKnife Centre',
'https://www.artemishospitals.com/doctor/profile/s-jayalakshmi'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
116,
1,
'Artemis Hospitals',
'Dr. Sachin Sethi (PT)',
'Principal Lead - Physiotherapy',
'Principal Lead - Physiotherapy',
'https://www.artemishospitals.com/doctor/profile/dr-sachin-sethi-pt'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
117,
1,
'Artemis Hospitals',
'Dr. Sakshi Karkra',
'Head - Pediatric Gastroenterology & Hepatology',
'Head - Pediatric Gastroenterology & Hepatology',
'https://www.artemishospitals.com/doctor/profile/sakshi-karkra'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
118,
1,
'Artemis Hospitals',
'Dr. Sameer Arora',
'Senior Consultant - Neurology',
'Senior Consultant - Neurology',
'https://www.artemishospitals.com/doctor/profile/dr-sameer-arora'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
119,
1,
'Artemis Hospitals',
'Dr. Sameer Mehrotra',
'Unit Chief - Interventional Cardiology & Electrophysiology',
'Unit Chief - Interventional Cardiology & Electrophysiology',
'https://www.artemishospitals.com/doctor/profile/dr-sameer-mehrotra'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
120,
1,
'Artemis Hospitals',
'Dr. Sandeep Chauhan',
'Head (Unit-III)',
'Head (Unit-III)',
'https://www.artemishospitals.com/doctor/profile/sandeep-chauhan'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
121,
1,
'Artemis Hospitals',
'Dr. Sandeep Goel',
'Sr. Consultant',
'Sr. Consultant',
'https://www.artemishospitals.com/doctor/profile/sandeep-goel'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
122,
1,
'Artemis Hospitals',
'Dr. Sanjay Mehta',
'Chairperson',
'Chairperson',
'https://www.artemishospitals.com/doctor/profile/dr-sanjay-mehta'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
123,
1,
'Artemis Hospitals',
'Dr. Sanjay Sarup',
'Head – Othopaedics (Unit-II) and Chief – Paediatric Orthopaedics & Spine Surgery',
'Head – Othopaedics (Unit-II) and Chief – Paediatric Orthopaedics & Spine Surgery',
'https://www.artemishospitals.com/doctor/profile/sanjay-sarup'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
124,
1,
'Artemis Hospitals',
'Dr. Sanjeev Srivastava',
'Sr. Consultant',
'Sr. Consultant',
'https://www.artemishospitals.com/doctor/profile/dr-sanjeev-srivastava'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
125,
1,
'Artemis Hospitals',
'Dr. Sarabpreet Singh',
'Head - Clinical Embryology & Andrology',
'Head - Clinical Embryology & Andrology',
'https://www.artemishospitals.com/doctor/profile/sarabpreet-singh'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
126,
1,
'Artemis Hospitals',
'Dr. Saurabh Anand',
'Chief - Neuroanaesthesia and Neurocritical Care',
'Chief - Neuroanaesthesia and Neurocritical Care',
'https://www.artemishospitals.com/doctor/profile/saurabh-anand'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
127,
1,
'Artemis Hospitals',
'Dr. Seema Dhir',
'Unit Head & Sr. Consultant - Internal Medicine',
'Unit Head & Sr. Consultant - Internal Medicine',
'https://www.artemishospitals.com/doctor/profile/seema-dhir'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
128,
1,
'Artemis Hospitals',
'Dr. Seema Lachala',
'Sr. Consultant',
'Sr. Consultant',
'https://www.artemishospitals.com/doctor/profile/seema-lachala'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
129,
1,
'Artemis Hospitals',
'Dr. Seerat Sandhu',
'Classified Consultant',
'Classified Consultant',
'https://www.artemishospitals.com/doctor/profile/dr-seerat-sandhu'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
130,
1,
'Artemis Hospitals',
'Dr. Shabana Parveen',
'Head Dietetics',
'Head Dietetics',
'https://www.artemishospitals.com/doctor/profile/dr-shabana-parveen'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
131,
1,
'Artemis Hospitals',
'Dr. Shashidhar TB',
'Head - Surgery (ENT)',
'Head - Surgery (ENT)',
'https://www.artemishospitals.com/doctor/profile/shashidhar-tb'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
132,
1,
'Artemis Hospitals',
'Dr. Shelly Mittal',
'Chief - Anaesthesia',
'Chief - Anaesthesia',
'https://www.artemishospitals.com/doctor/profile/shelly-mittal'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
133,
1,
'Artemis Hospitals',
'Dr. Shifa Yadav',
'Consultant - Dermatology',
'Consultant - Dermatology',
'https://www.artemishospitals.com/doctor/profile/dr-shifa-yadav'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
134,
1,
'Artemis Hospitals',
'Dr. Shubhra Shri Gupta',
'Principal Consultant - Neonatology and Incharge - Pediatric Cardiac Critical Care',
'Principal Consultant - Neonatology and Incharge - Pediatric Cardiac Critical Care',
'https://www.artemishospitals.com/doctor/profile/shubhra-shri-gupta'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
135,
1,
'Artemis Hospitals',
'Dr. Shweta Bansal',
'Unit Head & Sr. Consultant - Respiratory Disease & Sleep Medicine (Unit II)',
'Unit Head & Sr. Consultant - Respiratory Disease & Sleep Medicine (Unit II)',
'https://www.artemishospitals.com/doctor/profile/dr-shweta-bansal'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
136,
1,
'Artemis Hospitals',
'Dr. Shyam Sunder Mahansaria',
'Head - Liver Transplant & Sr. Consultant - GI & HPB Surgery',
'Head - Liver Transplant & Sr. Consultant - GI & HPB Surgery',
'https://www.artemishospitals.com/doctor/profile/shyam-sunder-mahansaria'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
137,
1,
'Artemis Hospitals',
'Dr. Sidharth Kumar Sethi',
'Pediatric Nephrologist',
'Pediatric Nephrologist',
'https://www.artemishospitals.com/doctor/profile/dr-sidharth-kumar-sethi'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
138,
1,
'Artemis Hospitals',
'Dr. SK Rajan',
'Chief - Neuro Spine Surgery & Additional Director - Neurosurgery',
'Chief - Neuro Spine Surgery & Additional Director - Neurosurgery',
'https://www.artemishospitals.com/doctor/profile/sk-rajan'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
139,
1,
'Artemis Hospitals',
'Dr. Sukriti Gupta',
'Sr. Consultant',
'Sr. Consultant',
'https://www.artemishospitals.com/doctor/profile/dr-sukriti-gupta'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
140,
1,
'Artemis Hospitals',
'Dr. Sumeet Agrawal',
'Chief - Rheumatology',
'Chief - Rheumatology',
'https://www.artemishospitals.com/doctor/profile/sumeet-agrawal'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
141,
1,
'Artemis Hospitals',
'Dr. Sumeet Arora',
'Sr. Consultant',
'Sr. Consultant',
'https://www.artemishospitals.com/doctor/profile/sumeet-arora'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
142,
1,
'Artemis Hospitals',
'Dr. Sumit Kumar',
'Consultant -: Orthopaedics & Spine Surgery',
'Consultant -: Orthopaedics & Spine Surgery',
'https://www.artemishospitals.com/doctor/profile/dr-sumit-kumar'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
143,
1,
'Artemis Hospitals',
'Dr. Sumit Singh',
'Chief - Neurology',
'Chief - Neurology',
'https://www.artemishospitals.com/doctor/profile/sumit-singh'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
144,
1,
'Artemis Hospitals',
'Dr. Surendra Nath Khanna',
'Chairperson, Adult Cardiac Surgery & Heart - Lung Transplant',
'Chairperson, Adult Cardiac Surgery & Heart - Lung Transplant',
'https://www.artemishospitals.com/doctor/profile/dr-surendra-nath-khanna'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
145,
1,
'Artemis Hospitals',
'Dr. Swati Aggarwal',
'Principal Consultant - Anaesthesia',
'Principal Consultant - Anaesthesia',
'https://www.artemishospitals.com/doctor/profile/swati-aggarwal'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
146,
1,
'Artemis Hospitals',
'Dr. Sweetha Susanne Mohan',
'Sr. Consultant',
'Sr. Consultant',
'https://www.artemishospitals.com/doctor/profile/sweetha-susanne-mohan'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
147,
1,
'Artemis Hospitals',
'Dr. Syed Tauqueer Fazal',
'Head & Coordinator – Diagnostic Radiology',
'Head & Coordinator – Diagnostic Radiology',
'https://www.artemishospitals.com/doctor/profile/syed-tauqueer-fazal'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
148,
1,
'Artemis Hospitals',
'Dr. Tajamul Syed Malik',
'Sr. Consultant - Nuclear Medicine',
'Sr. Consultant - Nuclear Medicine',
'https://www.artemishospitals.com/doctor/profile/tajamul-syed-malik'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
149,
1,
'Artemis Hospitals',
'Dr. Tapan Singh Chauhan',
'Sr. Consultant - Surgical Oncology, Robotics, GI & HPB, Gynae & Peritoneal Surface Oncology',
'Sr. Consultant - Surgical Oncology, Robotics, GI & HPB, Gynae & Peritoneal Surface Oncology',
'https://www.artemishospitals.com/doctor/profile/dr-tapan-singh-chauhan'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
150,
1,
'Artemis Hospitals',
'Dr. Tariq Matin',
'Director & Chief',
'Director & Chief',
'https://www.artemishospitals.com/doctor/profile/dr-tariq-matin'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
151,
1,
'Artemis Hospitals',
'Dr. Trisha Srivastava',
'Consultant',
'Consultant',
'https://www.artemishospitals.com/doctor/profile/dr-trisha-srivastava'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
152,
1,
'Artemis Hospitals',
'Dr. Varun Khanna',
'Consultant -: Orthopaedics & Spine Surgery',
'Consultant -: Orthopaedics & Spine Surgery',
'https://www.artemishospitals.com/doctor/profile/dr-varun-khanna'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
153,
1,
'Artemis Hospitals',
'Dr. Varun Mittal',
'Head - Kidney Transplant & Associate Chief - Uro-Oncology & Robotic Surgery (Unit I)',
'Head - Kidney Transplant & Associate Chief - Uro-Oncology & Robotic Surgery (Unit I)',
'https://www.artemishospitals.com/doctor/profile/dr-varun-mittal'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
154,
1,
'Artemis Hospitals',
'Dr. Vijay Mohan Hanjoora',
'Chief - Cardiac Anaesthesia',
'Chief - Cardiac Anaesthesia',
'https://www.artemishospitals.com/doctor/profile/vijay-mohan-hanjoora'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
155,
1,
'Artemis Hospitals',
'Dr. Vimal Kumar Dakour',
'Sr. Consultant - Orthpaedic & Joint Replacement',
'Sr. Consultant - Orthpaedic & Joint Replacement',
'https://www.artemishospitals.com/doctor/profile/dr-vimal-kumar-dakour'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
156,
1,
'Artemis Hospitals',
'Dr. Vineeta Raina',
'Sr. Consultant',
'Sr. Consultant',
'https://www.artemishospitals.com/doctor/profile/vineeta-raina'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
157,
1,
'Artemis Hospitals',
'Dr. Vipin Maheshwari',
'Sr. Consultant - Orthopaedics',
'Sr. Consultant - Orthopaedics',
'https://www.artemishospitals.com/doctor/profile/vipin-maheshwari'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
158,
1,
'Artemis Hospitals',
'Dr. Vishal Arora',
'Head - Ophthalmology',
'Head - Ophthalmology',
'https://www.artemishospitals.com/doctor/profile/dr-vishal-arora'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
159,
1,
'Artemis Hospitals',
'Dr. Vivek Barun',
'Sr. Consultant-Neurology & Epilepsy',
'Sr. Consultant-Neurology & Epilepsy',
'https://www.artemishospitals.com/doctor/profile/dr-vivek-barun'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
160,
1,
'Artemis Hospitals',
'Dr. Vivek Mohan',
'Associate Consultant',
'Associate Consultant',
'https://www.artemishospitals.com/doctor/profile/dr-vivek-mohan'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
161,
1,
'Artemis Hospitals',
'Dr. Vivek Vaibhav',
'Sr. Consultant - Orthopaedics (Unit I)',
'Sr. Consultant - Orthopaedics (Unit I)',
'https://www.artemishospitals.com/doctor/profile/dr-vivek-vaibhav'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
162,
1,
'Artemis Hospitals',
'Dr. Y Naveen',
'Head - Anesthesia for Oncology',
'Head - Anesthesia for Oncology',
'https://www.artemishospitals.com/doctor/profile/y-naveen'
);


INSERT INTO doctors
(
doctor_id,
hospital_id,
hospital_name,
doctor_name,
department,
specialty,
profile_url
)
VALUES
(
163,
1,
'Artemis Hospitals',
'Dr. Yatin Kukreja',
'Sr. Consultant - Emergency',
'Sr. Consultant - Emergency',
'https://www.artemishospitals.com/doctor/profile/yatin-kukreja'
);

